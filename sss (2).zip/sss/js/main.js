particlesJS.load('particles', '/js/particles.json')

document.getElementById("button1").addEventListener("click", function(){
    
    document.getElementById("text").style.color = "yellow";
    document.getElementById("text").style.background = "blue";

    document.getElementById("text1").style.color = "yellow";
    document.getElementById("text1").style.background = "blue";

    document.getElementById("text2").style.color = "yellow";
    document.getElementById("text2").style.background = "blue";
});